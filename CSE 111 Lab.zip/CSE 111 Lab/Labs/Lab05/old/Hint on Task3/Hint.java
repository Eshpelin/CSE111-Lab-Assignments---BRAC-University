//import java.util.*;
public class Hint{
  public static void main(String[]args){
    int a, b, c;
    a=7;
    /*int[] w;
    Scanner k = new Scanner(System.in);
    
    a=k.nextInt();
    b=k.nextInt();
    */
    c=a/0;
   // w=new int [90000000];
    
    System.out.println(c);
  }
}