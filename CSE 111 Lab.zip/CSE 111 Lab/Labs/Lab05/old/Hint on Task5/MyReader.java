import java.util.*;
public class MyReader{
    //modify following line so that this method can throw Exception
    int readInteger( ){
        Scanner k = new Scanner(System.in);
        String s;
        int answer;
        //Monay kori input nichchi ekta String, s er moddhay
        
        if (s contains the decimal point "."){
            // error banai
            
            // shei error throw kori karon
            // amake bollo read integer
            // aar dichche float / double
            
        }else{
            // string ta-kay number banai
            
        }

        // return kori
        
    }
}