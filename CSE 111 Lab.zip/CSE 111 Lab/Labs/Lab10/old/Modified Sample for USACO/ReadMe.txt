Many of you were having problem in understanding their FAQ on how to write your program and submit

We have modified their example program that adds two numbers and prints. 

Please find the modified Sample for USACO attached.



