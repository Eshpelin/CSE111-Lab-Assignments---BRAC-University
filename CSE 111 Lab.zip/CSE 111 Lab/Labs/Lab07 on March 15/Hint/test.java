import java.util.*;
class test{
  
  public static void main(String []avg){
    int i=10;
    recTest t=new recTest();
    t.printten(10);
    
    
  }
  
}