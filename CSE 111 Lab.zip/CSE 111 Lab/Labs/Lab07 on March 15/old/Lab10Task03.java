class Lab10Task03{
    public static void main(String[] args){
       int a =0;
       while(a<args.length)
       {
         System.out.println(args[i]);
         a++;
       }
       
    }
}
