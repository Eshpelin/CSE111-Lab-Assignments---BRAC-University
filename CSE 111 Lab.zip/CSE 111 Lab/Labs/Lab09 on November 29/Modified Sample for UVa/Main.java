
import java.io.*;
import java.util.*;


// Do not write public. class and file name has to be Main
class Main { 
    public static void main (String [] args) throws Exception {

      //instead of your own Scanner, use the following scanner to take input
      
        Scanner sc=new Scanner(System.in);     




 // your work starts here
        int i1 = sc.nextInt(); // first integer
        int i2 = sc.nextInt(); // second integer
 // your work ends here







        System.out.println(i1+i2); // output result

    }
}