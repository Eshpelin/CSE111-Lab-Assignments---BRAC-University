import java.util.*;
class Hint{
  public static void main(String[]args){
    int a, b, c;
    int[] w;
    Scanner k = new Scanner(System.in);
    
    a=k.nextInt();
    b=k.nextInt();
    
    c=a/b;
    w=new int [90000000];
    
    System.out.println(c);
  }
}